<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NTIC General Exam Processor</title>
	<?= stylesheet_link_tag() ?>
    <?= javascript_include_tag() ?>
</head>
<body>
	<div class="grid">
		<div class="form m-center">
			<a class="btn inline full r-margin" href="{{URL::route('index')}}">- -Return</a>
			<br><br>
		</div>
 	</div>
</body>
</html>
