<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NTIC General Exam Processor</title>
	
    {{ HTML::style('css/bootstrap.min.css') }}
</head>
<body>
	<div class="grid">
		<h1 class='h3 center'>Click save to approve</h1>
		<div class="form m-center">
			<div class="inline half r-margin">
				<a class="btn inline half r-margin" href="{{URL::route('index')}}">- -Restart</a>
				<a class="btn inline half" href="{{URL::route('index')}}?more=more">Do More</a>
			</div>
			<a class="btn inline half" href="{{URL::route('save')}}">Save To Database</a>
			<br><br>
		</div>
 	</div>
</body>
</html>
