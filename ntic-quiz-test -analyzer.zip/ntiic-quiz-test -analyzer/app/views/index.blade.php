<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NTIC General Exam Processor</title>
	<?= stylesheet_link_tag() ?>
    <?= javascript_include_tag() ?>
</head>
<body>
	<div class="grid">
		<h1 class='h2 center'>General Exam Processor (1000 Row at a Time)</h1>
		<form class="form m-center" method="post" enctype="multipart/form-data">
			<label class="h4">File Inputs</label>
			<input class="card full" type="file" name="file">
			<br>			
			<label class="h4">Answer key</label>
			<input class="card full" type="file" name="a_file">
			<br>
			<input class="btn full" type="submit" value="Upload">
		</form>
		{{$message}}
		<br>
		<div class="form m-center card">
			<a class="" href="{{URL::route('view')}}">View General Exam Results.</a><br><br>
			<a class="" href="{{URL::route('stats')}}">View General Exam Statistics.</a><br><br>
			<a class="" href="{{URL::route('delete')}}">Empty General Exam Database.</a>
		</div>
 	</div>
</body>
</html>
