<?php

use LaravelBook\Ardent\Ardent;

class Results extends Ardent {
	protected $table = 'results';
	protected $primaryKey = 'result_id';
}