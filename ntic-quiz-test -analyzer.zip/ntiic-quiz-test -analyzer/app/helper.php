<?php
function answerKeyGen($size,$print=true)
{
	
	$letters = "ABCDE";
	$rand_letter=array();
	for ($i = 0; $i < $size; $i++) {
		$int = rand(0,4);
		$rand_letter [$i]= $letters[$int];
	}
	
	if (!$print) return $rand_letter;
	
	echo '<table><tr>';
	foreach(answerKeyGen(100) as $column){
		echo  '<td>'.$column.'</td>';
	}
	echo '</tr></table>';
	
	return ;
}


function answer_key($answer_keys){
	$result=array();	
	foreach ($answer_keys as $ans_key){
		$result[strtoupper($ans_key[0])]=array_slice($ans_key, 1);
	}
	return $result;
}


function ge_processor($GE_input, $GE_answer_keys, $schools, $classes){
	$main_result=array();
	
	foreach($GE_input as $row){
		$result=array(null,null,null,null,null,0,0,0,0,0,0,0,false);
	
		//set id, school, class, major, name
		$result[0]=$row[0]; $result[1]=strtoupper($row[1]); $result[2]=strtoupper($row[2]); $result[3]=strtoupper($row[3]); $result[4]=$row[4];
	
		if(array_key_exists($result[1], $schools) and array_key_exists($result[2], $classes) and ((isset($row[0]) and !ctype_space($row[0])) or (isset($row[4]) and !ctype_space($row[4])))){
			if($result[3]==null) $curr_answer_key=$GE_answer_keys[strtoupper($row[2])];
			else $curr_answer_key=$GE_answer_keys[strtoupper($row[2]).' '.strtoupper($row[3])];		
			
			if (in_array($result[2], array('JSS1','JSS2','JSS3'))){
				$result[5]=count(array_intersect_assoc(array_slice($row,5,20), array_slice($curr_answer_key,0,20)));
				$result[6]=count(array_intersect_assoc(array_slice($row,25,20), array_slice($curr_answer_key,20,20)));
				$result[7]=count(array_intersect_assoc(array_slice($row,45,20), array_slice($curr_answer_key,40,20)));				
				$result[8]=count(array_intersect_assoc(array_slice($row,65,10), array_slice($curr_answer_key,60,10)));
				$result[9]=count(array_intersect_assoc(array_slice($row,75,10), array_slice($curr_answer_key,70,10)));
				$result[10]=count(array_intersect_assoc(array_slice($row,85,10), array_slice($curr_answer_key,80,10)));
				$result[11]=count(array_intersect_assoc(array_slice($row,95,10), array_slice($curr_answer_key,90,10)));
			}
			else{
				$result[5]=count(array_intersect_assoc(array_slice($row,5,20), array_slice($curr_answer_key,0,20)));
				$result[6]=count(array_intersect_assoc(array_slice($row,25,20), array_slice($curr_answer_key,20,20)));
				$result[7]=count(array_intersect_assoc(array_slice($row,45,20), array_slice($curr_answer_key,40,20)));
				$result[8]=count(array_intersect_assoc(array_slice($row,65,20), array_slice($curr_answer_key,60,20)));
				$result[9]=count(array_intersect_assoc(array_slice($row,85,20), array_slice($curr_answer_key,80,20)));
				$result[10]='NA';
				$result[11]='NA';
			}
		
		}
		else $result[12]=true;
		
		$main_result[]=$result;
	}	
	return $main_result;
}


function table($main_result){
	echo '<h1 class="h2 center">General Exam Results</h1>
		<table class="m-center">
		<tr>
			<th>No</th> <th>Student ID</th> 	<th>School</th>  <th>Class</th>  <th>Major</th>  <th>Name</th> 
		 	<th>Subject 1</th><th>Subject 2</th> <th>Subject 3</th>
			<th>Subject 4</th> <th>Subject 5</th> <th>Subject 6</th> <th>Subject 7</th>
		</tr>';
	$i=0;
	foreach($main_result as $row){
		$i++;
		if (array_pop($row)==true) echo '<tr class="red">';
		else echo '<tr>';
		echo  '<td>'.$i.'</td>';
		foreach ($row as $column){
			echo  '<td>'.$column.'</td>';		
		}
		echo '</tr>';
	}	
	echo '</table>';
}


function elo_table($main_result, $schools, $classes){
	echo '<h1 class="h2 center">General Exam Results</h1>
		<table class="m-center">
		<tr>
			<th>No</th> <th>Student ID</th> 	<th>School</th>  <th>Class</th>  <th>Major</th>  <th>Name</th>
		 	<th>Maths</th><th>English</th> <th>Basic Sci & Tech</th>
			<th>IRK/CRK</th> <th>Values Education</th> <th>Pre-Voc Std</th> <th>Cultural & Creative Art</th>
		</tr>';
	$i=0;
	foreach($main_result as $row){
		$i++;
		echo '<tr>';
			echo  '<td>'.$i.'</td>';
			echo  '<td>'.$row->student_id.'</td>';
			echo  '<td>'.$schools[$row->school_id].'</td>';
			echo  '<td>'.$classes[$row->class_id].'</td>';
			echo  '<td>'.$row->major.'</td>';
			echo  '<td>'.$row->name.'</td>';
			echo  '<td>'.$row->sub_1.'</td>';
			echo  '<td>'.$row->sub_2.'</td>';
			echo  '<td>'.$row->sub_3.'</td>';
			echo  '<td>'.$row->sub_4.'</td>';
			echo  '<td>'.$row->sub_5.'</td>';
			echo  '<td>'.$row->sub_6.'</td>';
			echo  '<td>'.$row->sub_7.'</td>';
		echo '</tr>';
	}
	echo '</table><br><br><br>';
}


function elo_table_ss($main_result, $schools, $classes,$subjects){
	echo '<h1 class="h2 center">General Exam Results</h1>
		<table class="m-center">
		<tr>
			<th>No</th> <th>Student ID</th> <th>School</th> <th>Class</th> <th>Major</th> <th>Name</th>
		 	<th>'.$subjects[0].'</th><th>'.$subjects[1].'</th> <th>'.$subjects[2].'</th>
			<th>'.$subjects[3].'</th> <th>'.$subjects[4].'</th>
		</tr>';
	$i=0;
	foreach($main_result as $row){
		$i++;
		echo '<tr>';
		echo  '<td>'.$i.'</td>';
		echo  '<td>'.$row->student_id.'</td>';
		echo  '<td>'.$schools[$row->school_id].'</td>';
		echo  '<td>'.$classes[$row->class_id].'</td>';
		echo  '<td>'.$row->major.'</td>';
		echo  '<td>'.$row->name.'</td>';
		echo  '<td>'.$row->sub_1.'</td>';
		echo  '<td>'.$row->sub_2.'</td>';
		echo  '<td>'.$row->sub_3.'</td>';
		echo  '<td>'.$row->sub_4.'</td>';
		echo  '<td>'.$row->sub_5.'</td>';
		echo '</tr>';
	}
	echo '</table><br><br><br>';
}

function test(){
	if (true or (true and false)){
		echo 'true';
	}
	else{
		echo 'false';
	};
}