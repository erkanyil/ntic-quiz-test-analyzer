<?php

use Illuminate\Support\Facades\Input;

class IndexController extends BaseController {

	private $schools=array('ABUJA GIRLS'=>303, 'ABUJA COED'=>304, 'ABUJA BOYS'=>305, 'KADUNA BOYS'=>403, 'KADUNA GIRLS'=>404, 'KANO BOYS'=>503, 'KANO GIRLS'=>504, 'OGUN BOYS'=>603, 'OGUN GIRLS'=>604, 'LAGOS COED'=>605, 'YOBE BOYS'=>702, 'YOBE GIRLS'=>703);
	private	$classes=array('JSS1'=>107,'JSS2'=>108,'JSS3'=>109,'SS1'=>110,'SS2'=>111,'SS3'=>112);
	private $answerkey=array('JSS1','JSS2','JSS3','SS1 ART', 'SS2 ART', 'SS3 ART', 'SS1 SCIENCE', 'SS2 SCIENCE', 'SS3 SCIENCE');
	private $subjects_ART=array('Maths','English','Economics','Government','Literature');
	private $subjects_SCIENCE=array('Maths','English','Physics','Chemistry','Biology');
	 
	
	public function index()
	{	
			
		$more=Input::get('more');
		if (!($more=='more')) Session::forget('results');
		
		$message=Session::get('message');
		return View::make('index')->with('message', $message);
	}

	public function getfile(){

		$answer_key = array(array('  A','B ',' C ','D       ',' E','A              ','  B    '),
							array('  A','Z ',' Z ','Z       ',' E','Z              ','  A    '));

		$result=array();	
		
		foreach ($answer_key as $ans_key){
		$result[strtoupper($ans_key)]=str_replace(' ','',$ans_key);
		}
		
		return dd($result);
	}	


	public function process(){

		$file=Input::file('file');
		$answer_file=Input::file('a_file');


		if (isset($file)&&isset($answer_file)){
			//Loads excel files
			$GE_input=Excel::selectSheetsByIndex(0)->load($file)->get()->take()->toArray();
			$GE_answer_keys=Excel::selectSheetsByIndex(0)->load($answer_file)->get()->take()->toArray();	

			//Genarates answer key and check correctness
			$GE_answer_keys=answer_key($GE_answer_keys);			
			if(!empty(array_diff(array_keys($GE_answer_keys),$this->answerkey))) {
				return Redirect::to(URL::route('index'))->with('message', '<h2 class="center error">Answer key has format problem.<br><br>Correct format is: JSS1 -- JSS2 -- JSS3 -- SS1 ART -- SS2 ART -- SS3 ART -- SS1 SCIENCE -- SS2 SCIENCE -- SS3 SCIENCE</h2>');
			}
			
			$results=ge_processor($GE_input, $GE_answer_keys, $this->schools,$this->classes );
						
			if(Session::has('results'))	Session::set('results', array_merge(Session::pull('results'),$results));
			else Session::set('results', $results);

			//Prints result as table 
			table($results);
			return View::make('preview');
		}
		else {
			return Redirect::to(URL::route('index'))->with('message', '<h2 class="center error">Excel Files required.</h2>');
		}
	}
		
	
	public function save(){
		
		//Retrieve processed result
		$results=Session::get('results');
		Session::forget('results');

		foreach ($results as $res){
			if (array_pop($res)==false){
				$result =New Results;
				$result->student_id=$res[0];
				$result->school_id=$this->schools[$res[1]];
				$result->class_id=$this->classes[$res[2]];
				$result->major=trim(preg_replace('/\s+/',' ', $res[3]));
				$result->name=trim(preg_replace('/\s+/',' ', $res[4]));
				$result->sub_1=$res[5];
				$result->sub_2=$res[6];
				$result->sub_3=$res[7];
				$result->sub_4=$res[8];
				$result->sub_5=$res[9];
				$result->sub_6=$res[10];
				$result->sub_7=$res[11];
				$result->save();
			}
		}
		
		return Redirect::to(URL::route('index'))->with('message', '<h2 class="center msg">General Exam Results Processing Complete.</h2>');
	}

	
	public function view()
	{
		$result=Results::where('major','=','')->get();
		$result_art=Results::where('major','=','ART')->get();
		$result_science=Results::where('major','=','SCIENCE')->get();
		
		if (!$result->isEmpty() or !$result_art->isEmpty() or !$result_science->isEmpty()){ 
			elo_table($result,array_flip ($this->schools),array_flip ($this->classes));
			elo_table_ss($result_art,array_flip ($this->schools),array_flip ($this->classes),$this->subjects_ART);
			elo_table_ss($result_science,array_flip ($this->schools),array_flip ($this->classes),$this->subjects_SCIENCE);
		}
		
		else return Redirect::to(URL::route('index'))->with('message', '<h2 class="center error">No General Exam Results Exist For Viewing.</h2>');
		
		return View::make('view');
	}
	
	public function delete()
	{
		//Delete old results
		Results::truncate();
		Session::forget('results');
		return Redirect::to(URL::route('index'))->with('message', '<h2 class="center msg">General Exam Database emptied.</h2>');
	}
}
