<?php

use Illuminate\Support\Facades\Input;
class StatsController extends BaseController {

	private $schools=array('ABUJA GIRLS'=>303, 'ABUJA COED'=>304, 'ABUJA BOYS'=>305, 'KADUNA BOYS'=>403, 'KADUNA GIRLS'=>404, 'KANO BOYS'=>503, 'KANO GIRLS'=>504, 'OGUN BOYS'=>603, 'OGUN GIRLS'=>604, 'LAGOS COED'=>605, 'YOBE BOYS'=>702, 'YOBE GIRLS'=>703);
	private	$classes=array('JSS1'=>107,'JSS2'=>108,'JSS3'=>109,'SS1'=>110,'SS2'=>111,'SS3'=>112);
	private $classes_major=array('JSS1'=>107,'JSS2'=>108,'JSS3'=>109,'SS1 ART'=>110, 'SS1 SCIENCE'=>110, 'SS2 ART'=>111, 'SS2 SCIENCE'=>111, 'SS3 ART'=>112, 'SS3 SCIENCE'=>112);
	private $subjects=array('ART'=>array('Maths','English','Economics','Government','Literature'), 'SCIENCE'=>array('Maths','English','Physics','Chemistry','Biology'));
	
	public function index()
	{			
		if(Results::first()){ 		
			first_three($this->classes_major, array_flip ($this->schools), $this->subjects);
			grand_average(array_flip ($this->classes));
			grand_average_ss(array_flip ($this->classes),'ART',$this->subjects['ART']);
			grand_average_ss(array_flip ($this->classes),'SCIENCE',$this->subjects['SCIENCE']);
			$schools_rank=school_ranking_per_class($this->classes_major, array_flip ($this->schools), $this->subjects);
			school_ranking_overall($schools_rank);
			return View::make('stats');
		}
		else return Redirect::to(URL::route('index'))->with('message', '<h2 class="center error">No General Exam Results Empty.</h2>');
	}	
}
