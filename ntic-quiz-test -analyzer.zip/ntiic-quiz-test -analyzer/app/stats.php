<?php


function first_three($classes_major, $schools, $subjects) {
		
	echo '<h1 class="h2 center">Top 3 Students per class</h1>';
	foreach($classes_major as $key=>$class){			
		$MAJOR=array_get(explode(' ',$key),'1', "");
		
		if ($MAJOR==""){

			$sql="SELECT school_id, name, sub_1,sub_2, sub_3, sub_4, sub_5, sub_6, sub_7,(sub_1 + sub_2 + sub_3 + sub_4 + sub_5 + sub_6 + sub_7) as total
						FROM results
						WHERE class_id=".$class." AND major ='".$MAJOR.
						"' ORDER BY total DESC
						LIMIT 20";
		}
		else{

			$sql="SELECT school_id, name, sub_1, sub_2, sub_3, sub_4, sub_5, (sub_1 + sub_2 + sub_3 + sub_4 + sub_5) as total
						FROM results
						WHERE class_id=".$class." AND major ='".$MAJOR.
									"' ORDER BY total DESC
						LIMIT 20";			
		}
		
		$query=DB::select(DB::raw($sql));
		
		$position=1;
		$prev_score=0;

		if ($MAJOR==""){
			echo '		
				<table class="m-center">
					<tr>
						 <th>Position</th> <th>Class</th> <th>School</th> <th>Name</th> <th>Maths</th><th>English</th> <th>Basic Sci & Tech</th>
						<th>IRK/CRK</th> <th>Values Education</th> <th>Pre-Voc Std</th> <th>Cultural & Creative Art</th> <th>Total</th>
					</tr>';		
	
			
			foreach($query as $row){			
				if ($row->total<$prev_score) $position++;			
				if ($position>3) break;						
					echo '<tr>';
						echo  '<td>'.$position.'</td>';
						echo  '<td>'.$key.'</td>';
						echo  '<td>'.$schools[$row->school_id].'</td>';
						echo  '<td>'.$row->name.'</td>';
						echo  '<td>'.$row->sub_1.'</td>';
						echo  '<td>'.$row->sub_2.'</td>';
						echo  '<td>'.$row->sub_3.'</td>';
						echo  '<td>'.$row->sub_4.'</td>';
						echo  '<td>'.$row->sub_5.'</td>';
						echo  '<td>'.$row->sub_6.'</td>';
						echo  '<td>'.$row->sub_7.'</td>';
						echo  '<td>'.$row->total.'</td>';
					echo '</tr>';
					
				$prev_score=$row->total;
				
			}
		}
		else{
			$subject=$subjects[$MAJOR];
			echo '
				<table class="m-center">
					<tr>
						 <th>Position</th> <th>Class</th> <th>School</th> <th>Name</th> <th>'.$subject[0].'</th><th>'.$subject[1].'</th> <th>'.$subject[2].'</th>
						<th>'.$subject[3].'</th> <th>'.$subject[4].'</th> <th>Total</th>
					</tr>';
			
				
			foreach($query as $row){
				if ($row->total<$prev_score) $position++;
				if ($position>3) break;
				echo '<tr>';
				echo  '<td>'.$position.'</td>';
				echo  '<td>'.$key.'</td>';
				echo  '<td>'.$schools[$row->school_id].'</td>';
				echo  '<td>'.$row->name.'</td>';
				echo  '<td>'.$row->sub_1.'</td>';
				echo  '<td>'.$row->sub_2.'</td>';
				echo  '<td>'.$row->sub_3.'</td>';
				echo  '<td>'.$row->sub_4.'</td>';
				echo  '<td>'.$row->sub_5.'</td>';
				echo  '<td>'.$row->total.'</td>';
				echo '</tr>';
					
				$prev_score=$row->total;
			
			}
		}
		
		echo '</table><br><br>';		
	}	
}


function grand_average($classes) {
		$sql="SELECT class_id, major, round(avg(sub_1),1) as sub_1, round(avg(sub_2),1) as sub_2, round(avg(sub_3),1) as sub_3,
		round(avg(sub_4),1) as sub_4, round(avg(sub_5),1) as sub_5, round(avg(sub_6),1) as sub_6, round(avg(sub_7),1) as sub_7, 
		(round(avg(sub_1),1)+round(avg(sub_2),1)+round(avg(sub_3),1)+round(avg(sub_4),1)+round(avg(sub_5),1)+round(avg(sub_6),1)+round(avg(sub_7),1)) as total
		FROM results
		WHERE major='' 
		GROUP BY class_id, major
		ORDER BY class_id ASC";

		$query=DB::select(DB::raw($sql));

		echo '<br> <br>
			<h1 class="h2 center">Grand Average</h1>
			<table class="m-center">
				<tr>
					<th>Grand Average</th> <th>Maths</th><th>English</th> <th>Basic Sci & Tech</th>
						<th>IRK/CRK</th> <th>Values Education</th> <th>Pre-Voc Std</th> <th>Cultural & Creative Art</th> <th>Total</th>
				</tr>';

		foreach($query as $row){
			echo '<tr>';
			echo  '<td>'.$classes[$row->class_id].' '.$row->major.'</td>';
			echo  '<td>'.$row->sub_1.'</td>';
			echo  '<td>'.$row->sub_2.'</td>';
			echo  '<td>'.$row->sub_3.'</td>';
			echo  '<td>'.$row->sub_4.'</td>';
			echo  '<td>'.$row->sub_5.'</td>';
			echo  '<td>'.$row->sub_6.'</td>';
			echo  '<td>'.$row->sub_7.'</td>';
			echo  '<td>'.$row->total.'</td>';
			echo '</tr>';				
		}
		echo '</table>';
}


function grand_average_ss($classes, $major, $subject) {
	$sql="SELECT class_id, major, round(avg(sub_1),1) as sub_1, round(avg(sub_2),1) as sub_2, round(avg(sub_3),1) as sub_3,
		round(avg(sub_4),1) as sub_4, round(avg(sub_5),1) as sub_5,
		(round(avg(sub_1),1)+round(avg(sub_2),1)+round(avg(sub_3),1)+round(avg(sub_4),1)+round(avg(sub_5),1)) as total
		FROM results
		WHERE major='".$major."' 		
		GROUP BY class_id, major
		ORDER BY class_id ASC";

	$query=DB::select(DB::raw($sql));

	echo '<br> <br>
			<h1 class="h2 center">Grand Average '.$major.'</h1>
			<table class="m-center">
				<tr>
					<th>Grand Average</th> <th>'.$subject[0].'</th><th>'.$subject[1].'</th> <th>'.$subject[2].'</th>
						<th>'.$subject[3].'</th> <th>'.$subject[4].'</th> <th>Total</th>
				</tr>';

	foreach($query as $row){
		echo '<tr>';
		echo  '<td>'.$classes[$row->class_id].' '.$row->major.'</td>';
		echo  '<td>'.$row->sub_1.'</td>';
		echo  '<td>'.$row->sub_2.'</td>';
		echo  '<td>'.$row->sub_3.'</td>';
		echo  '<td>'.$row->sub_4.'</td>';
		echo  '<td>'.$row->sub_5.'</td>';
		echo  '<td>'.$row->total.'</td>';
		echo '</tr>';
	}
	echo '</table>';
}


function school_ranking_per_class($classes_major, $schools, $subjects) {
	$school_rank=array();
	$class_index=0;
	
	echo '<br><br><h1 class="h2 center">School Rankings by classes</h1>';
	
	foreach($classes_major as $key=>$class){
		$MAJOR=array_get(explode(' ',$key),'1', "");
		
		if ($MAJOR==""){
			
			$sql="SELECT class_id, school_id, major, round(avg(sub_1),1) as sub_1, round(avg(sub_2),1) as sub_2, round(avg(sub_3),1) as sub_3, round(avg(sub_4),1) as sub_4, round(avg(sub_5),1) as sub_5, round(avg(sub_6),1) as sub_6,round(avg(sub_7),1) as sub_7, 
			(round(avg(sub_1),1)+round(avg(sub_2),1)+round(avg(sub_3),1)+round(avg(sub_4),1)+round(avg(sub_5),1)+round(avg(sub_6),1)+round(avg(sub_7),1)) as total
			FROM results
			WHERE class_id=".$class." AND major='".$MAJOR.
			"' GROUP BY class_id, school_id, major
			ORDER BY class_id ASC, major ASC, total DESC";
		}
		else{
			
			$sql="SELECT class_id, school_id, major, round(avg(sub_1),1) as sub_1, round(avg(sub_2),1) as sub_2, round(avg(sub_3),1) as sub_3, round(avg(sub_4),1) as sub_4, round(avg(sub_5),1) as sub_5,
			(round(avg(sub_1),1)+round(avg(sub_2),1)+round(avg(sub_3),1)+round(avg(sub_4),1)+round(avg(sub_5),1)) as total
			FROM results
			WHERE class_id=".$class." AND major='".$MAJOR.
			"' GROUP BY class_id, school_id, major
			ORDER BY class_id ASC, major ASC, total DESC";			
		}
	
		$query=DB::select(DB::raw($sql));
		
		$position=1;
		$prev_score=0;
		
				if ($MAJOR==""){	
				echo '<table class="m-center">
							<tr>
								<th>Rank</th><th>'.$key.'</th> <th>Maths</th><th>English</th> <th>Basic Sci & Tech</th>
						<th>IRK/CRK</th> <th>Values Education</th> <th>Pre-Voc Std</th> <th>Cultural & Creative Art</th> <th>Total</th>
							</tr>';
			
				foreach($query as $row){
					if ($row->total<$prev_score) $position++;
						
					echo '<tr>';
						echo  '<td>'.$position.'</td>';
						echo  '<td>'.$schools[$row->school_id].'</td>';
						echo  '<td>'.$row->sub_1.'</td>';
						echo  '<td>'.$row->sub_2.'</td>';
						echo  '<td>'.$row->sub_3.'</td>';
						echo  '<td>'.$row->sub_4.'</td>';
						echo  '<td>'.$row->sub_5.'</td>';
						echo  '<td>'.$row->sub_6.'</td>';
						echo  '<td>'.$row->sub_7.'</td>';
						echo  '<td>'.$row->total.'</td>';
					echo '</tr>';
					
					$school_rank[$schools[$row->school_id]][$class_index]=$position;
					
					$prev_score=$row->total;
				}
			}				
			else{
				$subject=$subjects[$MAJOR];
				echo '<table class="m-center">
							<tr>
								<th>Rank</th><th>'.$key.'</th> <th>'.$subject[0].'</th><th>'.$subject[1].'</th> <th>'.$subject[2].'</th>
						<th>'.$subject[3].'</th> <th>'.$subject[4].'</th> <th>Total</th>
							</tr>';
			
				foreach($query as $row){
					if ($row->total<$prev_score) $position++;
						
					echo '<tr>';
						echo  '<td>'.$position.'</td>';
						echo  '<td>'.$schools[$row->school_id].'</td>';
						echo  '<td>'.$row->sub_1.'</td>';
						echo  '<td>'.$row->sub_2.'</td>';
						echo  '<td>'.$row->sub_3.'</td>';
						echo  '<td>'.$row->sub_4.'</td>';
						echo  '<td>'.$row->sub_5.'</td>';
						echo  '<td>'.$row->total.'</td>';
					echo '</tr>';
					
					$school_rank[$schools[$row->school_id]][$class_index]=$position;
					
					$prev_score=$row->total;
				}
			}
		echo '</table><br> <br>';
		$class_index++;
	}
	return $school_rank;
}


function school_ranking_overall( $schools_rank) {
	
	foreach($schools_rank as $key=>$row){
		$row['school']=$key;
		$weight=array_get($row,'0',9)+array_get($row,'1',9)+array_get($row,'2',9)+array_get($row,'3',9)+array_get($row,'4',9)+array_get($row,'5',9)+array_get($row,'6',9)+array_get($row,'7',9)+array_get($row,'8',9);
		$proper_rank[$weight]=$row;
	}
	
	ksort($proper_rank);
	
	echo '<br> <br>
		<h1 class="h2 center">School overall ranking</h1>
		<table class="m-center">
		<tr>
		<th>School</th> <th>JSS1</th> <th>JSS2</th> <th>JSS3</th><th>SS1 ART</th> <th>SS1 SCIENECE</th> <th>SS2 ART</th> <th>SS2 SCIENECE</th> <th>SS3 ART</th> <th>SS3 SCIENECE</th> <th>Rank</th>
		</tr>';

	$rank=1;
		
	foreach($proper_rank as $row){
			
	echo '<tr>';
		echo  '<td>'.array_get($row,'school','').'</td>';
		echo  '<td>'.array_get($row,'0','').'</td>';
		echo  '<td>'.array_get($row,'1','').'</td>';
		echo  '<td>'.array_get($row,'2','').'</td>';
		echo  '<td>'.array_get($row,'3','').'</td>';
		echo  '<td>'.array_get($row,'4','').'</td>';
		echo  '<td>'.array_get($row,'5','').'</td>';
		echo  '<td>'.array_get($row,'6','').'</td>';
		echo  '<td>'.array_get($row,'7','').'</td>';
		echo  '<td>'.array_get($row,'8','').'</td>';
		echo  '<td>'.$rank.'</td>';
		echo '</tr>';
				
		$rank++;
	}
	echo '</table>';
}